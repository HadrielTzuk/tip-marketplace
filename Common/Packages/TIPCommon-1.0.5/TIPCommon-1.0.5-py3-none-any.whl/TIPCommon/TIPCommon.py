import sys

def extract_script_param(siemplify, input_dictionary, param_name, default_value=None, input_type=str, is_mandatory=False, print_value=False):
    # internal param validation:
    if not siemplify:
        raise Exception("Parameter 'siemplify' cannot be None")

    if not param_name:
        raise Exception("Parameter 'param_name' cannot be None")

    if default_value and not (type(default_value) == input_type):
        raise Exception("Given default_value of '{0}' doesn't match expected type {1}".format(default_value, input_type.__name__))

    #  =========== start validation logic =====================
    value = input_dictionary.get(param_name)

    if not value:
        if is_mandatory:
            raise Exception("Missing mandatory parameter {0}".format(param_name))
        else:
            value = default_value
            siemplify.LOGGER.info("Paramter {0} was not found or was empty, used default_value {1} instead".format(param_name, default_value))

    # None values should not be converted.
    if value is None:
        return None

    if input_type == bool:
        lowered = str(value).lower()
        valid_lowered_bool_values = [str(True).lower(), str(False).lower(), str(bool(None)).lower()] # In Python - None and bool False are the same logicly
        if lowered not in valid_lowered_bool_values:
            raise Exception("Paramater named {0}, with value {1} isn't a valid BOOL".format(param_name, value))
        result = lowered == str(True).lower()
    elif input_type == int:
        result = int(value)
    elif input_type == float:
        result = float(value)
    elif input_type == str:
        result = str(value)
    else:
        raise Exception("input_type {0} isn't not supported for conversion".format(input_type.__name__))

    if print_value:
        siemplify.LOGGER.info("{}: {}".format(param_name, result))

    return result


def extract_configuration_param(siemplify, provider_name, param_name, default_value=None, input_type=str,
                                is_mandatory=False, print_value=False):
    if not provider_name:
        raise Exception("provider_name cannot be None\empty")

    configuration = siemplify.get_configuration(provider_name)
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=configuration,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)


def extract_action_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False,
                         print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)

def extract_connector_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False, print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)

def is_python_37():
    return sys.version_info >= (3, 7)