from .main import chars, char_names, beavis , cheese , daemon , cow , dragon , ghostbusters , kitty , meow , milk , stegosaurus , stimpy , turkey , turtle , tux, about
