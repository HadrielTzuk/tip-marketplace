# -*- coding: utf-8 -*-

neutral = [
    'Se abre el ascensor y hay un programador dentro, le preguntan: - ¿Sube o baja? A lo que el programador responde: - Sí.',
    'Qué le dice un bit al otro? Nos vemos en el bus.',
]

adult = [
    '¿Qué es una mujer objeto? Un instancia de una mujer con clase',
    '- Cuántos dalmatas habia en la peli? - 101. - Por el culo te la hinco!',
    'Encuentran programador muerto en la ducha con un bote de champu: "enjabonar, aclarar y vuelta a empezar"',
    'Esto es un mainframe que le dice a un PC: "tan pequeno y ya "computas"?'
]

jokes_es = {
    'neutral': neutral,
    'adult': adult,
    'all': neutral + adult,
}
