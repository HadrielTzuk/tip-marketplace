# -*- coding: utf-8 -*-

neutral = [
    'No jokes found.',
]

jokes_de = {
    'neutral': neutral,
    'all': neutral,
}
