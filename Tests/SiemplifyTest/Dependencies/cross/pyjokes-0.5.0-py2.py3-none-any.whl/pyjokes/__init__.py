from __future__ import absolute_import
from .pyjokes import get_joke, get_jokes


__version__ = '0.5.0'
