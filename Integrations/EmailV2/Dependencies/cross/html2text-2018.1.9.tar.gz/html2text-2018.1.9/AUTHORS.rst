``html2text`` was originally written by Aaron Swartz.

The AUTHORS/Contributors are (and/or have been):

* Aaron Swartz
* Yariv Barkan
* Alex Musayev
* Matěj Cepl
* Stefano Rivera
* Alireza Savand <alireza.savand@gmail.com>
* Ivan Gromov <summer.is.gone@gmail.com>
* Jocelyn Delalande <jdelalande@oasiswork.fr>
* Matt Dorn <matt.dorn@gmail.com>
* Miguel Tavares <mgontav@gmail.com>
* Scott Blackburn <scott@skipflag.com>
* Peter Wu <peter@lekensteyn.nl>
* Arjoonn Sharma <gh: theSage21>
* Ali Mohammad <gh: alawibaba>
* Albert Berger <gh: nbdsp>
* Etienne Millon <me@emillon.org>
* John C F <gh: critiqjo>
* Mikhail Melnik <by.zumzoom@gmail.com>
* Andres Rey
* Ciprian Miclaus
* Toshihiro Kamiya <kamiya@mbj.nifty.com>
* Matt Dennewitz <mattdennewitz@gmail.com>
* Jonathan Sundqvist <sundqvist.jonathan@gmail.com>
* Simon Meers <gh: DrMeers>
* Kurt McKee <contactme@kurtmckee.org>

Maintainer:

* Alireza Savand <alireza.savand@gmail.com>
