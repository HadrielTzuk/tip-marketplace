  * Run this command: 
    
        ls -l *.html

  * ?
  * Profit!

