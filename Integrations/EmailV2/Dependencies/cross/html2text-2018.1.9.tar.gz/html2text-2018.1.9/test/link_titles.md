[ first example](http://example.com "MyTitle")  
[ second example](http://example.com)

