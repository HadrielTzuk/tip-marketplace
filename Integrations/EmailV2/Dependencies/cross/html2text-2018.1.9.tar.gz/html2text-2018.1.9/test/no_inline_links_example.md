[Googler][1] No href No href but title available [ Example][2] [ [ [ link text
][3]][3]][3]

   [1]: http://google.com

   [2]: http://example.com (Example title)

   [3]: http://example.com (abc)

