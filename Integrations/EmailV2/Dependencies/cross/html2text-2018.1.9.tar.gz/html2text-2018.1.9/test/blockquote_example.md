> The time has come, the Walrus said, to speak of many things.

