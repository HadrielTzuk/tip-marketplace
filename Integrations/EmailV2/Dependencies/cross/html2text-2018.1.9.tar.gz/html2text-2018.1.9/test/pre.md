
    a
    b
    c

Ensure that HTML that starts with a crowded `<pre>` is converted to reasonable
Markdown.

