[ ![ALT TEXT][1] ][2]  
[![ALT TEXT][1]][2]  
[![http://example.com][1]][2]

   [1]: http://example.com/img.png

   [2]: http://example.com

