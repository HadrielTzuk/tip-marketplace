![An image without dimensions](image_without_dimensions.jpg) <img
src='image_with_width.jpg' width='300' alt='An image with a width attr' />
<img src='image_with_width.jpg' height='300' alt='An image with a height attr'
/> <img src='image_with_width_and_height.jpg' width='300' height='300' alt='An
image with width and height' /> <img src='image_with_width_and_height.jpg'
width='300' height='300' /> ![](image_with_width_and_height.jpg)

