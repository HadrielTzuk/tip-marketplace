# Processing empty hyperlinks

This test checks whether empty hyperlinks still appear in the markdown result.

[](http://some.link)

[](http://some.link)

