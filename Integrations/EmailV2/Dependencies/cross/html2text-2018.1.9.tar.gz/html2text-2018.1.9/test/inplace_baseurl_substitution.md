![read2text header image](http://brettterpstra.com/uploads/2012/01/read2textheader.jpg)

[BrettTerpstra.com](http://brettterpstra.com/)
