Normal text with 'pre' code block.

[code]

    import os
    
    def function():
        a = 1
    
[/code]

Normal text continues.

