from html2text.cli import main

main()
