:mod:`Crypto.Util.asn1` module
==============================

This module provides minimal support for encoding and decoding `ASN.1`_ DER
objects.

.. _`ASN.1`: ftp://ftp.rsasecurity.com/pub/pkcs/ascii/layman.asc

.. automodule:: Crypto.Util.asn1
    :members:
