import sys
import copy
import chardet
import datetime
import arrow

from functools import reduce
from SiemplifyUtils import utc_now, convert_datetime_to_unix_time, unix_now, convert_string_to_unix_time
from .DataStream import DataStreamFactory


##########################
#       CONSTANTS        #
##########################

WHITELIST_FILTER = 1
BLACKLIST_FILTER = 2

UNIX_FORMAT = 1
DATETIME_FORMAT = 2
STORED_IDS_LIMIT = 1000

NUM_OF_HOURS_IN_DAY = 24
NUM_OF_MILLI_IN_SEC = 1000
NUM_OF_SEC_IN_SEC = 1
NUM_OF_HOURS_IN_3_DAYS = 72
TIMEOUT_THRESHOLD = 0.9

IDS_DB_KEY = 'ids'
IDS_FILE_NAME = 'ids.json'


########################################################################################
#            EXTRACT  METHODS              ##            EXTRACT  METHODS              #
########################################################################################

def extract_script_param(siemplify, input_dictionary, param_name, default_value=None, input_type=str,
                         is_mandatory=False, print_value=False, remove_whitespaces=True):
    # internal param validation:
    if not siemplify:
        raise Exception("Parameter 'siemplify' cannot be None")

    if not param_name:
        raise Exception("Parameter 'param_name' cannot be None")

    if default_value and not (type(default_value) == input_type):
        raise Exception(
            "Given default_value of '{0}' doesn't match expected type {1}".format(default_value, input_type.__name__))

    #  =========== start validation logic =====================
    value = input_dictionary.get(param_name)

    if not value:
        if is_mandatory:
            raise Exception("Missing mandatory parameter {0}".format(param_name))
        else:
            value = default_value
            siemplify.LOGGER.info(
                "Paramter {0} was not found or was empty, used default_value {1} instead".format(param_name,
                                                                                                 default_value))
            return value

    if print_value:
        siemplify.LOGGER.info(u"{}: {}".format(param_name, value))

    # None values should not be converted.
    if value is None:
        return None

    if input_type == bool:
        lowered = str(value).lower()
        valid_lowered_bool_values = [str(True).lower(), str(False).lower(),
                                     str(bool(None)).lower()]  # In Python - None and bool False are the same logicly
        if lowered not in valid_lowered_bool_values:
            raise Exception("Paramater named {0}, with value {1} isn't a valid BOOL".format(param_name, value))
        result = lowered == str(True).lower()
    elif input_type == int:
        result = int(value)
    elif input_type == float:
        result = float(value)
    elif input_type == str:
        result = str(value)
    elif input_type == unicode:
        result = value
    else:
        raise Exception("input_type {0} isn't not supported for conversion".format(input_type.__name__))

    if remove_whitespaces:
        return clean_result(result)

    return result


def extract_configuration_param(siemplify, provider_name, param_name, default_value=None, input_type=str,
                                is_mandatory=False, print_value=False, remove_whitespaces=True):
    if not provider_name:
        raise Exception("provider_name cannot be None/empty")

    configuration = siemplify.get_configuration(provider_name)
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=configuration,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value,
                                remove_whitespaces=remove_whitespaces)


def extract_action_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False,
                         print_value=False, remove_whitespaces=True):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value,
                                remove_whitespaces=remove_whitespaces)


def extract_connector_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False,
                            print_value=False, remove_whitespaces=True):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value,
                                remove_whitespaces=remove_whitespaces)


########################################################################################
#              DATA  METHODS               ##              DATA  METHODS               #
########################################################################################

def construct_csv(list_of_dicts):
    """
    Constructs a csv from list_of_dicts
    :param list_of_dicts: The list_of_dicts to add to the csv (list_of_dicts are list of flat dicts).
    :return: (dict) csv formatted list.
    """
    csv_output = []
    if not list_of_dicts:
        return csv_output
    headers = reduce(set.union, map(set, map(dict.keys, list_of_dicts)))
    unicode_headers = []
    for header in headers:
        header = adjust_to_csv(header)
        header = get_unicode(header)
        unicode_headers.append(header)
    csv_output.append(u",".join(unicode_headers))
    for result in list_of_dicts:
        csv_row = []
        for header in headers:
            cell_value = result.get(header)
            cell_value = adjust_to_csv(cell_value)
            cell_value = get_unicode(cell_value)

            # Replace problematic commas
            cell_value = cell_value.replace(u',', u' ')
            # Append values to the row
            csv_row.append(cell_value)
        # Append row to the output
        csv_output.append(u",".join(csv_row))
    return csv_output


def adjust_to_csv(value):
    if value is None:
        return ""
    return value


def dict_to_flat(target_dict):
    """
    Receives nested dictionary and returns it as a flat dictionary
    :param target_dict: (dict).
    :return: Flat dict : (dict).
    """
    target_dict = copy.deepcopy(target_dict)

    def expand(raw_key, raw_value):
        key = raw_key
        value = raw_value
        """
        :param key: (str)
        :param value: (str).
        :return: Recursive function.
        """
        if value is None:
            return [(get_unicode(key), u"")]
        elif isinstance(value, dict):
            # Handle dict type value
            return [(u"{0}_{1}".format(get_unicode(key),
                                       get_unicode(sub_key)),
                     get_unicode(sub_value)) for sub_key, sub_value in dict_to_flat(value).items()]
        elif isinstance(value, list):
            # Handle list type value
            count = 1
            l = []
            items_to_remove = []
            for value_item in value:
                if isinstance(value_item, dict):
                    # Handle nested dict in list
                    l.extend([(u"{0}_{1}_{2}".format(get_unicode(key),
                                                     get_unicode(count),
                                                     get_unicode(sub_key)),
                               sub_value)
                              for sub_key, sub_value in dict_to_flat(value_item).items()])
                    items_to_remove.append(value_item)
                    count += 1
                elif isinstance(value_item, list):
                    l.extend(expand(get_unicode(key) + u'_' + get_unicode(count), value_item))
                    count += 1
                    items_to_remove.append(value_item)

            for value_item in items_to_remove:
                value.remove(value_item)

            for value_item in value:
                l.extend([(get_unicode(key) + u'_' + get_unicode(count), value_item)])
                count += 1

            return l
        else:
            return [(get_unicode(key), get_unicode(value))]

    items = [item for sub_key, sub_value in target_dict.items() for item in
             expand(sub_key, sub_value)]
    return dict(items)


def flat_dict_to_csv(flat_dict, property_header=u"Property", value_header=u"Value"):
    """
    Turns flat dict to CSV format string list. property_header and value_header are for customizing the CSV header
    :param flat_dict: (dict)
    :param property_header: (unicode)
    :param value_header: (unicode).
    :return: CSV format string list : (dict).
    """
    csv_format = []
    csv_head = u"{}, {}".format(property_header, value_header)
    csv_format.append(csv_head)
    for key, value in flat_dict.items():
        safe_key = get_unicode(key)
        safe_value = get_unicode(value)
        csv_format.append(u"{0},{1}".format(safe_key, safe_value))
    return csv_format


def add_prefix_to_dict(given_dict, prefix):
    """
    add prefix to the given dict keys
    :param given_dict: (dict)
    :param prefix: (str) prefix to be added to the given dict.
    :return: (dict).
    """
    return {u'{0}_{1}'.format(get_unicode(prefix), get_unicode(key)): value for key, value in given_dict.items()}


def add_prefix_to_dict_keys(target_dict, prefix):
    """
    add prefix to the given dict keys
    :param target_dict: (dict)
    :param prefix: (str) prefix to be added to the given dict.
    :return: Result Dictionary (dict).
    """
    result_dict = {}
    for key, val in target_dict.iteritems():
        new_key = u"{0}_{1}".format(get_unicode(prefix), get_unicode(key))
        result_dict[new_key] = val

    return result_dict


def get_unicode(value):
    """
    Get the unicode of a value.
    """
    if is_python_37():
        return str(value)
    if isinstance(value, unicode):
        return value
    if not isinstance(value, basestring):
        # Validate that the cell is a basestring. If not convert it to string
        try:
            value = str(value)
        except Exception:
            value = u"Unable to get text representation of object"
    if value is None:
        # If the value is empty, leave the cell empty
        value = u""
    if isinstance(value, str):
        try:
            value = value.decode("utf8")
        except UnicodeDecodeError:
            try:
                encoding = chardet.detect(value).get('encoding')
                value = value.decode(encoding)
            except Exception:
                value = u"Unable to decode value (unknown encoding)"

    return value


def string_to_multi_value(string_value, delimiter=',', only_unique=False):
    """
    String to multi value.
    :param string_value: (str) String value to convert multi value.
    :param delimiter: (str) Delimiter to extract multi values from single value string.
    :param only_unique: (bool) include only uniq values.
    :return: (dict) fixed dictionary.
    """
    if not string_value:
        return []
    values = [single_value.strip() for single_value in string_value.split(delimiter) if single_value.strip()]
    if only_unique:
        seen = set()
        return [value for value in values if not (value in seen or seen.add(value))]
    return values


def convert_comma_separated_to_list(comma_separated):
    """
    Convert comma-separated string to list
    :param comma_separated: String with comma-separated values
    :return: List of values
    """
    return [item.strip() for item in comma_separated.split(',')] if comma_separated else []


def convert_list_to_comma_string(values_list):
    """
    Convert list to comma-separated string
    :param values_list: List of values
    :return: String with comma-separated values
    """
    return ', '.join(str(v) for v in values_list) if values_list and isinstance(values_list, list) else values_list


########################################################################################
#            UTILITY  METHODS              ##            UTILITY  METHODS              #
########################################################################################

def clean_result(value):
    """
    Strip the value from unnecessary spaces before or after the value
    :param value: (str) the value to clean.
    :return: (str) A clean-from-spaces version of the original value
    (If the value was originally clean, it will return it).
    """
    try:
        return value.strip()
    except Exception:
        return value


def is_python_37():
    """
    Check if the python version of the system is 3.7 or above.
    :return: (bool) True if the current python version is at least 3.7.
    """
    return sys.version_info >= (3, 7)


def platform_supports_db(siemplify):
    """
    Check if the platform supports database usage.
    :return: (bool) True if the siemplify SDK object has an attribute called "set_connector_context_property".
    """

    if hasattr(siemplify, 'set_connector_context_property'):
        return True
    return False


def is_empty_string_or_none(data):
    """
    Check if the data is an 'empty string' or 'None'.
    :return: (bool) True if the supplied data is 'None', or if it only contains an empty string "".
    """

    if data is None or data == "":
        return True
    return False


def cast_keys_to_int(data):
    """
    Cast the keys to integers
    :param data: (dict) the data whose keys will be cast to ints.
    :return: (dict) A new dict with its keys as ints.
    """
    return {int(k): v for k, v in data.items()}


def none_to_default_value(value_to_check, value_to_return_if_none):
    """
    Check if the current value is None. If it is, replace it with another value. If not, return the original value
    :param value_to_check: (dict/list/str) The value you want to replace if is 'None
    :param value_to_return_if_none: (dict/list/str) Supply the value to assign to the other value in case it is 'None'.
    :return: (dict/list/str) Replaced value if it's' 'None' or the original value if it isn't 'None'.
    """
    if value_to_check is None:
        value_to_check = value_to_return_if_none
    return value_to_check


########################################################################################
#              READ  METHODS               ##              READ  METHODS               #
########################################################################################

def read_content(siemplify, file_name, db_key, default_value_to_return=None, identifier=None):
    """
    Read the content of a ConnectorDBStream object.
    If the object contains no data, does not exist, return a default value
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param file_name: (str) the name of the file to be validated (in case the platform uses files)
    :param db_key: (str) the name of the key to be validated (in case the platform uses database)
    :param default_value_to_return: (dict/list/str) the default value to be set in case a new file/key is created.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of {} (dict) will be set as the new default value
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    :return: (dict) The content inside the DataStream object, the content passes through 'json.loads' before returning.
             If the content could not be parsed as a json or if no content was found,
             the default value will return as-is (see "default_value_to_return" parameter doc for further explanation).
    """

    data = DataStreamFactory.get_stream_object(file_name, db_key, siemplify, identifier)

    default_value_to_return = none_to_default_value(default_value_to_return, {})

    return data.read_content(default_value_to_return)


def read_ids(siemplify, default_value_to_return=None, identifier=None, ids_file_name=IDS_FILE_NAME, db_key=IDS_DB_KEY):
    """
    Read IDs from a ConnectorDBStream object.
    If the object contains no data, does not exist, return a default value
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param default_value_to_return: (dict/list/str) the default value to be set in case a new file/key is created.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of [] (list) will be set as the new default value
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    :param ids_file_name: {str} the file name where ids should be saved when FileStream object had been created
    :param db_key: {str} the file name where ids should be saved when FileStream object had been created
    :return: (list) List of IDs inside the DataStream object, the content passes through 'json.loads' before returning.
             If the content could not be parsed as a json or if no content was found,
             the default value will return as-is (see "default_value_to_return" parameter doc for further explanation).
    """

    default_value_to_return = none_to_default_value(default_value_to_return, [])

    return read_content(siemplify, ids_file_name, db_key, default_value_to_return, identifier)


def read_ids_by_timestamp(siemplify, offset_in_hours=NUM_OF_HOURS_IN_3_DAYS, default_value_to_return=None,
                          convert_to_milliseconds=False, cast_keys_to_integers=False, offset_is_in_days=False,
                          identifier=None, ids_file_name=IDS_FILE_NAME, db_key=IDS_DB_KEY):
    """
    Read IDs from a ConnectorDBStream object.
    If the object contains no data, does not exist, return a default value
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param offset_in_hours: (int) The IDs time limit (offset value) in hours
                            *Default value: 72 hours
    :param convert_to_milliseconds: (bool) Transform each ID's timestamp (unix) from seconds to milliseconds
                                    *Default value: False
    :param cast_keys_to_integers: (bool) Cast the keys to integers
                                  *Default value: False
    :param default_value_to_return: (dict/list/str) the default value to be set in case a new file/key is created.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of {} (dict) will be set as the new default value
    :param offset_is_in_days: (bool) If the offset supplied to this method is in days, please mark this as True for
                                     converting the offset days into hours
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    :param ids_file_name: {str} the file name where ids should be saved when FileStream object had been created
    :param db_key: {str} the file name where ids should be saved when FileStream object had been created
    :return: (list) List of IDs inside the DataStream object, the content passes through 'json.loads' before returning.
             If the content could not be parsed as a json or if no content was found,
             the default value will return as-is (see "default_value_to_return" parameter doc for further explanation).
    """

    existing_ids = read_content(siemplify, ids_file_name, db_key, default_value_to_return, identifier)

    try:
        filtered_ids = filter_old_ids_by_timestamp(
            ids=existing_ids,
            offset_in_hours=offset_in_hours,
            convert_to_milliseconds=convert_to_milliseconds,
            offset_is_in_days=offset_is_in_days
        )
        if cast_keys_to_integers:
            return cast_keys_to_int(filtered_ids)

        return filtered_ids

    except Exception as e:
        siemplify.LOGGER.error('Unable to read ids file: {}'.format(e))
        siemplify.LOGGER.exception(e)

        default_value_to_return = none_to_default_value(default_value_to_return, {})
        return default_value_to_return


########################################################################################
#              WRITE  METHODS              ##              WRITE  METHODS              #
########################################################################################

def write_content(siemplify, content_to_write, file_name, db_key, default_value_to_set=None, identifier=None):
    """
    Write content into a ConnectorDBStream object.
    If the object contains no data, does not exist, return the default
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param content_to_write: (dict/list/str) Content that would be written to the dedicated data stream.
                               *Note that the content passes through "json.dumps" before getting written
    :param file_name: (str) the name of the file to be validated (in case the platform uses files)
    :param db_key: (str) the name of the key to be validated (in case the platform uses database)
    :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                    *Note that the default value passes through "json.dumps" before getting written.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of {} (dict) will be set as the new default value
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    """

    data = DataStreamFactory.get_stream_object(file_name, db_key, siemplify, identifier)

    default_value_to_set = none_to_default_value(default_value_to_set, {})

    data.write_content(content_to_write, default_value_to_set)


def write_ids(siemplify, ids, default_value_to_set=None, stored_ids_limit=STORED_IDS_LIMIT, identifier=None,
              ids_file_name=IDS_FILE_NAME, db_key=IDS_DB_KEY):
    """
    Write the last 1,000 IDs into a ConnectorDBStream object.
    If the object contains no data, does not exist, return the default
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param ids: (dict/list/str) Content that would be written to the dedicated data stream.
                               *Note that the content passes through "json.dumps" before getting written
    :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                    *Note that the default value passes through "json.dumps" before getting written.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of [] (list) will be set as the new default value
    :param stored_ids_limit: (int) The number of recent IDs from the existing ids which will be written.
                                Default is the 1,000 most recent IDs
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    :param ids_file_name: {str} the file name where ids should be saved when FileStream object had been created
    :param db_key: {str} the file name where ids should be saved when FileStream object had been created
    """

    default_value_to_set = none_to_default_value(default_value_to_set, [])

    ids = ids[-stored_ids_limit:]
    write_content(siemplify, ids, ids_file_name, db_key, default_value_to_set, identifier)


def write_ids_with_timestamp(siemplify, ids, default_value_to_set=None, identifier=None, ids_file_name=IDS_FILE_NAME,
                             db_key=IDS_DB_KEY):
    """
    Write IDs into a ConnectorDBStream object.
    If the object contains no data, does not exist, return the default
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param ids: (dict/list/str) Content that would be written to the dedicated data stream.
                               *Note that the content passes through "json.dumps" before getting written
    :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                    *Note that the default value passes through "json.dumps" before getting written.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of {} (dict) will be set as the new default value
    :param identifier: (str) The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    :param ids_file_name: (str) the file name where ids should be saved when FileStream object had been created
    :param db_key: (str) the file name where ids should be saved when FileStream object had been created
    """

    default_value_to_set = none_to_default_value(default_value_to_set, {})

    write_content(siemplify, ids, ids_file_name, db_key, default_value_to_set, identifier)


########################################################################################
#              TIME  METHODS               ##              TIME  METHODS               #
########################################################################################

def validate_timestamp(last_run_timestamp, offset_in_hours, offset_is_in_days=False):
    """
    Validate timestamp in range
    :param last_run_timestamp: (datetime) last run timestamp
    :param offset_in_hours: (int) time limit (offset value) in hours
    :param offset_is_in_days: (bool) If the offset supplied to this method is in days, please mark this as True for
                                     converting the offset days into hours.
    :return: (datetime) if first run, return current time minus offset time, else return timestamp from file.
    """

    current_time = utc_now()

    if offset_is_in_days:
        offset_in_hours = offset_in_hours * NUM_OF_HOURS_IN_DAY

    if current_time - last_run_timestamp > datetime.timedelta(hours=offset_in_hours):
        return current_time - datetime.timedelta(hours=offset_in_hours)
    else:
        return last_run_timestamp


def save_timestamp(siemplify, alerts, timestamp_key='timestamp', incrementation_value=0, log_timestamp=True,
                   convert_timestamp_to_micro_time=False, convert_a_string_timestamp_to_unix=False):
    """
        Save last timestamp for given alerts
        :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
        :param alerts: (dict) The list of alerts to find the last timestamp
        :param timestamp_key: (str) key for getting timestamp from alert
        :param incrementation_value: (int) The value to increment last timestamp by milliseconds
        :param log_timestamp: (bool) Whether log timestamp or not
        :param convert_timestamp_to_micro_time: {bool} timestamp * 1000 if True
        :param convert_a_string_timestamp_to_unix: If the timestamp in the raw data is in the form of a string
         - convert it to unix before saving it.
        :return: (bool) Is timestamp updated.
        """

    if not alerts:
        siemplify.LOGGER.info('Timestamp is not updated since no alerts fetched')
        return False

    if convert_a_string_timestamp_to_unix:
        alerts = sorted(alerts, key=lambda alert: convert_string_to_unix_time(getattr(alert, timestamp_key)))
        last_timestamp = convert_string_to_unix_time(getattr(alerts[-1], timestamp_key)) + incrementation_value
    else:
        alerts = sorted(alerts, key=lambda alert: int(getattr(alert, timestamp_key)))
        last_timestamp = int(getattr(alerts[-1], timestamp_key)) + incrementation_value

    last_timestamp = last_timestamp * NUM_OF_MILLI_IN_SEC if convert_timestamp_to_micro_time else last_timestamp
    if log_timestamp:
        siemplify.LOGGER.info('Last timestamp is :{}'.format(last_timestamp))

    siemplify.save_timestamp(new_timestamp=last_timestamp)
    return True


def get_last_success_time(siemplify, offset_with_metric, time_format=DATETIME_FORMAT, print_value=True,
                          microtime=False):
    """
    Get last success time datetime
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param offset_with_metric: (dict) metric and value. Ex {'hours': 1}
    :param time_format: (int) The format of the output time. Ex DATETIME, UNIX
    :param print_value: (bool) Whether log the value or not
    :param microtime: (bool) If True return unix time including microtime.
    :return: (time) If first run, return current time minus offset time, else return timestamp from file.
    """

    last_run_timestamp = siemplify.fetch_timestamp(datetime_format=True)
    offset = datetime.timedelta(**offset_with_metric)
    current_time = utc_now()
    # Check if first run
    datetime_result = current_time - offset if current_time - last_run_timestamp > offset else last_run_timestamp
    unix_result = convert_datetime_to_unix_time(datetime_result)
    unix_result = unix_result if not microtime else int(unix_result / NUM_OF_MILLI_IN_SEC)

    if print_value:
        siemplify.LOGGER.info('Last success time. Date time:{}. Unix:{}'.format(datetime_result, unix_result))
    return unix_result if time_format == UNIX_FORMAT else datetime_result


def siemplify_fetch_timestamp(siemplify, datetime_format=False, timezone=False):
    last_time = siemplify.fetch_timestamp(datetime_format=datetime_format, timezone=timezone)
    if last_time == 0:
        siemplify.LOGGER.info('Timestamp key does not exist in the database. Initiating with value: 0.')
    return last_time


def siemplify_save_timestamp(siemplify, datetime_format=False, timezone=False, new_timestamp=unix_now()):
    siemplify.save_timestamp(datetime_format=datetime_format, timezone=timezone, new_timestamp=new_timestamp)


def is_approaching_timeout(connector_starting_time, python_process_timeout, timeout_threshold=TIMEOUT_THRESHOLD):
    """
    Check if a timeout is approaching
    :param connector_starting_time: (int) Connector start time
    :param python_process_timeout: (int) The python process timeout
    :param timeout_threshold: (float) the timeout threshold limit
    :return: (bool) True if timeout is close, False otherwise.
    """
    processing_time_ms = unix_now() - connector_starting_time
    return processing_time_ms > python_process_timeout * NUM_OF_MILLI_IN_SEC * timeout_threshold


########################################################################################
#               OTHER  METHODS             ##               OTHER  METHODS             #
########################################################################################

def validate_existence(file_name, db_key, default_value_to_set, siemplify, identifier=None):
    """
    Validate the existence of a DataStream object.
    If it does not exist, initiate it with default value
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param file_name: (str) the name of the file to be validated (in case the platform uses files)
    :param db_key: (str) the name of the key to be validated (in case the platform uses database)
    :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                 *Note that the default value passes through "json.dumps" before getting written
    :param identifier: The connector's identifier attribute.
                       If no value is supplied (therefore the default value 'None' is used),
                       the default identifier will be given using the current siemplify object:
                       ('self.siemplify.context.connector_info.identifier').
    """

    data = DataStreamFactory.get_stream_object(file_name, db_key, siemplify, identifier)
    data.validate_existence(default_value_to_set)


def is_overflowed(siemplify, alert_info, is_test_run):
    """
    Check if overflowed
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param alert_info: (AlertInfo)
    :param is_test_run: (bool) Whether test run or not.
    :return: (bool).
    """
    try:
        return siemplify.is_overflowed_alert(
            environment=alert_info.environment,
            alert_identifier=alert_info.ticket_id,
            alert_name=alert_info.rule_generator,
            product=alert_info.device_product)

    except Exception as err:
        siemplify.LOGGER.error('Error validation connector overflow, ERROR: {}'.format(err))
        siemplify.LOGGER.exception(err)
        if is_test_run:
            raise

    return False


def filter_old_ids(alert_ids, existing_ids):
    """
    Filter ids that were already processed
    :param alert_ids: (list) List of new ids from the alert to filter
    :param existing_ids: (list) List of ids to compare to
    :return: (list) List of filtered ids
    """
    new_alert_ids = []

    for alert_id in alert_ids:
        if alert_id not in existing_ids.keys():
            new_alert_ids.append(alert_id)

    return new_alert_ids


def filter_old_ids_by_timestamp(ids, offset_in_hours, convert_to_milliseconds, offset_is_in_days):
    """
    Filter ids that are older than IDS_HOURS_LIMIT hours
    :param ids: (dict) The ids to filter
    :param offset_in_hours: (int) The IDs time limit (offset value) in hours
    :param offset_is_in_days: (bool) If the offset supplied to this method is in days, please mark this as True for
                                     converting the offset days into hours.
    :param convert_to_milliseconds: (bool) Transform each ID's timestamp (unix) from seconds to milliseconds.
    :return: (dict) The filtered ids.
    """
    filtered_ids = {}
    milliseconds = NUM_OF_MILLI_IN_SEC if convert_to_milliseconds else NUM_OF_SEC_IN_SEC

    if offset_is_in_days:
        offset_in_hours = offset_in_hours * NUM_OF_HOURS_IN_DAY

    for alert_id, timestamp in ids.items():
        if timestamp > arrow.utcnow().shift(hours=-offset_in_hours).timestamp * milliseconds:
            filtered_ids[alert_id] = timestamp

    return filtered_ids


def filter_old_alerts(siemplify, alerts, existing_ids, id_key="alert_id"):
    """
    Filter alerts that were already processed
    :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
    :param alerts: (list) List of Alert objects
    :param existing_ids: {list} List of ids to filter
    :param id_key: (str) The key of identifier.
                    The key under which the ids can be found in the alert.
                    Default is "alert_id"
    :return: (list) List of filtered Alert objects
    """
    filtered_alerts = []

    for alert in alerts:
        ids = getattr(alert, id_key)

        if ids not in existing_ids:
            filtered_alerts.append(alert)
        else:
            siemplify.LOGGER.info("The alert {} skipped since it has been fetched before".format(ids))

    return filtered_alerts

