"""
Custom encodings
"""
