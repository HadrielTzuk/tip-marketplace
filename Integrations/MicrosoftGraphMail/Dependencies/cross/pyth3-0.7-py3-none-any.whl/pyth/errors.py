class WrongFileType(ValueError):
    pass

