"""
RTF 1.5

This was the version used in Word97, and the first to support Unicode,
making it the most compatible choice.
"""
