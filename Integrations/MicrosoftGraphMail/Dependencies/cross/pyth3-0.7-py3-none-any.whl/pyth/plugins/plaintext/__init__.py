"""
Plaintext
"""

