"""
Python object input
"""

