import json
import re
import os


class EnvironmentHandle(object):
    """
    handle environment logic
    environment_field_name + environment_regex + environment map.json
    """
    def __init__(self, map_file, logger, environment_field_name, environment_regex, default_environment):
        self.map_file = map_file
        self.logger = logger
        self.environment_field_name = environment_field_name
        # if environment_regex is null or empty, turn it into ".*" (aka: select everything)
        self.environment_regex = environment_regex if environment_regex else ".*"
        self.default_environment = default_environment

    def get_environment(self, data):
        """
        Get environment using all reoccurring environment logic
        environment_field_name + environment_regex + environment map.json
        first check if the user entered environment_field_name (from where to fetch)
        Then, if regex pattern given - extract environment
        In the end, try to resolve the found environment to its mapped alias - using the map file
        If nothing supply, return the default connector environment
        :param data: {dict} fetch the environment value from this data field (can be the alert or the event)
        :return: {string} environment
        """
        if self.environment_field_name and data.get(self.environment_field_name):
            # Get the environment from the given field
            environment = data.get(self.environment_field_name, "")

            if self.environment_regex and self.environment_regex != ".*":
                # If regex pattern given - extract environment
                match = re.search(self.environment_regex, environment)

                if match:
                    # Get the first matching value to match the pattern
                    environment = match.group()

            # Try to resolve the found environment to its mapped alias.
            # If the found environment / extracted environment is empty
            # use the default environment
            mapped_environment = self._get_mapped_environment(environment) if environment else self.default_environment
            return mapped_environment

        return self.default_environment

    def _get_mapped_environment(self, original_env):
        """
        Get mapped environment alias from mapping file
        :param original_env: {str} The environment to try to resolve
        :return: {str} The resolved alias (if no alias - returns the original env)
        """
        try:
            if not os.path.exists(self.map_file):
                with open(self.map_file, 'w+') as map_file:
                    map_file.write(json.dumps(
                        {"Original environment name": "Desired environment name",
                         "Env1": "MyEnv1"}))
                    self.logger.info(
                        "Mapping file was created at {}".format(unicode(map_file).encode("utf-8")))
        except Exception as e:
            self.logger.error("Unable to create mapping file: {}".format(str(e)))
            self.logger.exception(e)

        try:
            with open(self.map_file, 'r+') as map_file:
                mappings = json.loads(map_file.read())
        except Exception as e:
            self.logger.error(
                "Unable to read environment mappings: {}".format(str(e)))
            mappings = {}

        if not isinstance(mappings, dict):
            self.logger.LOGGER.error(
                "Mappings are not in valid format. Environment will not be mapped.")
            return original_env

        return mappings.get(original_env, original_env)
