class XmlParserContext(object):
    """Parser context when parsing XML elements"""

    def __init__(self):
        self.schemas = []
