from requests import Session


class SiemplifySession(Session):
    def __init__(self, sensitive_data_arr=[]):
        Session.__init__(self)
        self.sensitive_data_arr = sensitive_data_arr

    def request(self, method, url, **kwargs):
        try:
            return super(SiemplifySession, self).request(method, url, **kwargs)
        except Exception as e:
            err_msg = e.message
            try:
                e.args = map(lambda err: self.encode_sensitive_data(err), e.args)
                e.message = self.encode_sensitive_data(e.message)
            except Exception:
                raise Exception(self.encode_sensitive_data(err_msg))
            raise

    def encode_sensitive_data(self, message):
        """
        Encode sensitive data
        :param message: {str} The error message which may contain sensitive data
        :return: {str} The error message with encoded sensitive data
        """
        for sensitive_data in self.sensitive_data_arr:
            message = message.replace(sensitive_data, self.encode_data(sensitive_data))
        return message

    @staticmethod
    def encode_data(sensitive_data):
        """
        Encode string
        :param sensitive_data: {str} String to be encoded
        :return: {str} Encoded string
        """
        if len(sensitive_data) > 1:
            return u"{}...{}".format(sensitive_data[0], sensitive_data[-1])
        return sensitive_data
