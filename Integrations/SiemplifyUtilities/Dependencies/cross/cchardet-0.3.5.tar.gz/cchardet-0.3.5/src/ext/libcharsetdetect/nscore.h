#include "prtypes.h"
#define NS_OK 0
#define nsnull 0L
typedef PRUint32 nsresult;
#define NS_ERROR_OUT_OF_MEMORY ((nsresult) 0x8007000eL)
#define NS_ASSERTION(A,B)
