# -*- coding: utf-8 -*-

"""Top-level package for msg_parser."""

from msg_parser import MsOxMessage
