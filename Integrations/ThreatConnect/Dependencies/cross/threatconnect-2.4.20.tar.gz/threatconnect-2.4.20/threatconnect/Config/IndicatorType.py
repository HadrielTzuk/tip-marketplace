""" third-party """
from enum import Enum


class IndicatorType(Enum):
    """ """
    ADDRESSES = 515
    EMAIL_ADDRESSES = 525
    FILES = 535
    HOSTS = 545
    URLS = 555
    CUSTOM_INDICATORS = 565
