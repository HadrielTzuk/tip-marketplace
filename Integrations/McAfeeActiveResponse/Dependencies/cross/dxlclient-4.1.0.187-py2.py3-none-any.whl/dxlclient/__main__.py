# -*- coding: utf-8 -*-
################################################################################
# Copyright (c) 2018 McAfee LLC - All Rights Reserved.
################################################################################

""" dxlclient bootstrap for CLI subcommands. """

from __future__ import absolute_import
from dxlclient._cli import cli_run

cli_run()
