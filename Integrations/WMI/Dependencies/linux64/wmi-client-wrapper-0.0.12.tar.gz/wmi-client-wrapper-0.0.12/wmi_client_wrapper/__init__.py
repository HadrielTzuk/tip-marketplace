from wrapper import WmiClientWrapper
