import sys

def extract_script_param(siemplify, input_dictionary, param_name, default_value=None, input_type=str, is_mandatory=False, print_value=False):
    # internal param validation:
    if not siemplify:
        raise Exception("Parameter 'siemplify' cannot be None")

    if not param_name:
        raise Exception("Parameter 'param_name' cannot be None")

    if default_value and not (type(default_value) == input_type):
        raise Exception("Given default_value of '{0}' doesn't match expected type {1}".format(default_value, input_type.__name__))

    #  =========== start validation logic =====================
    value = input_dictionary.get(param_name)

    if not value:
        if is_mandatory:
            raise Exception("Missing mandatory parameter {0}".format(param_name))
        else:
            value = default_value
            siemplify.LOGGER.info("Paramter {0} was not found or was empty, used default_value {1} instead".format(param_name, default_value))
            return value

    if print_value:
        siemplify.LOGGER.info(u"{}: {}".format(param_name, value))

    # None values should not be converted.
    if value is None:
        return None

    if input_type == bool:
        lowered = value.lower()
        valid_lowered_bool_values = [str(True).lower(), str(False).lower(), str(bool(None)).lower()] # In Python - None and bool False are the same logicly
        if lowered not in valid_lowered_bool_values:
            raise Exception("Paramater named {0}, with value {1} isn't a valid BOOL".format(param_name, value))
        result = lowered == str(True).lower()
    elif input_type == int:
        result = int(value)
    elif input_type == float:
        result = float(value)
    elif input_type == str:
        result = str(value)
    elif input_type == unicode:
        result = value
    else:
        raise Exception("input_type {0} isn't not supported for conversion".format(input_type.__name__))

    return result


def extract_configuration_param(siemplify, provider_name, param_name, default_value=None, input_type=str,
                                is_mandatory=False, print_value=False):
    if not provider_name:
        raise Exception("provider_name cannot be None\empty")

    configuration = siemplify.get_configuration(provider_name)
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=configuration,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)


def extract_action_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False,
                         print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)

def extract_connector_param(siemplify, param_name, default_value=None, input_type=str, is_mandatory=False, print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)

def is_python_37():
    return sys.version_info >= (3, 7)

def construct_csv(list_of_dicts):
    """
    Constructs a csv from list_of_dicts
    :param list_of_dicts: The list_of_dicts to add to the csv (list_of_dicts are list of flat dicts)
    :return: {list} csv formatted list
    """
    csv_output = []
    if not list_of_dicts:
        return csv_output
    headers = reduce(set.union, map(set, map(dict.keys, list_of_dicts)))
    csv_output.append(u",".join(headers))
    for result in list_of_dicts:
        csv_row = []
        for header in headers:
            cell_value = result.get(header)
            if not isinstance(cell_value, basestring):
                # Validate that the cell is a basestring. If not convert it to string
                cell_value = str(cell_value)
            if not cell_value:
                # If the value is empty, leave the cell empty
                cell_value = u""
            if isinstance(cell_value, str):
                try:
                    cell_value = cell_value.decode("utf8")
                except UnicodeDecodeError:
                    cell_value = u"Unable to decode value (unknown encoding)"

            # Replace problematic commas
            cell_value = cell_value.replace(u',', u' ')
            # Append values to the row
            csv_row.append(cell_value)
        # Append row to the output
        csv_output.append(u",".join(csv_row))
    return csv_output