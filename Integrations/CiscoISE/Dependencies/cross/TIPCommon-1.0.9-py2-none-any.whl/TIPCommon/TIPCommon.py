import sys
import copy
import chardet


def extract_script_param(siemplify, input_dictionary, param_name, default_value=None, input_type=unicode,
                         is_mandatory=False, print_value=False):
    # internal param validation:
    if not siemplify:
        raise Exception("Parameter 'siemplify' cannot be None")

    if not param_name:
        raise Exception("Parameter 'param_name' cannot be None")

    if default_value and not (type(default_value) == input_type):
        raise Exception(
            "Given default_value of '{0}' doesn't match expected type {1}".format(default_value, input_type.__name__))

    #  =========== start validation logic =====================
    value = input_dictionary.get(param_name)

    if not value:
        if is_mandatory:
            raise Exception("Missing mandatory parameter {0}".format(param_name))
        else:
            value = default_value
            siemplify.LOGGER.info(
                "Paramter {0} was not found or was empty, used default_value {1} instead".format(param_name,
                                                                                                 default_value))
            return value

    if print_value:
        siemplify.LOGGER.info(u"{}: {}".format(param_name, value))

    # None values should not be converted.
    if value is None:
        return None

    if input_type == bool:
        lowered = value.lower()
        valid_lowered_bool_values = [str(True).lower(), str(False).lower(),
                                     str(bool(None)).lower()]  # In Python - None and bool False are the same logicly
        if lowered not in valid_lowered_bool_values:
            raise Exception("Paramater named {0}, with value {1} isn't a valid BOOL".format(param_name, value))
        result = lowered == str(True).lower()
    elif input_type == int:
        result = int(value)
    elif input_type == float:
        result = float(value)
    elif input_type == str:
        result = str(value)
    elif input_type == unicode:
        result = value
    else:
        raise Exception("input_type {0} isn't not supported for conversion".format(input_type.__name__))

    return result


def extract_configuration_param(siemplify, provider_name, param_name, default_value=None, input_type=unicode,
                                is_mandatory=False, print_value=False):
    if not provider_name:
        raise Exception("provider_name cannot be None\empty")

    configuration = siemplify.get_configuration(provider_name)
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=configuration,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)


def extract_action_param(siemplify, param_name, default_value=None, input_type=unicode, is_mandatory=False,
                         print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)


def extract_connector_param(siemplify, param_name, default_value=None, input_type=unicode, is_mandatory=False,
                            print_value=False):
    return extract_script_param(siemplify=siemplify,
                                input_dictionary=siemplify.parameters,
                                param_name=param_name,
                                default_value=default_value,
                                input_type=input_type,
                                is_mandatory=is_mandatory,
                                print_value=print_value)


def is_python_37():
    return sys.version_info >= (3, 7)


def construct_csv(list_of_dicts):
    """
    Constructs a csv from list_of_dicts
    :param list_of_dicts: The list_of_dicts to add to the csv (list_of_dicts are list of flat dicts)
    :return: {list} csv formatted list
    """
    csv_output = []
    if not list_of_dicts:
        return csv_output
    headers = reduce(set.union, map(set, map(dict.keys, list_of_dicts)))
    unicode_headers = []
    for header in headers:
        header = get_unicode(header)
        unicode_headers.append(header)
    csv_output.append(u",".join(unicode_headers))
    for result in list_of_dicts:
        csv_row = []
        for header in headers:
            cell_value = result.get(header)
            cell_value = get_unicode(cell_value)

            # Replace problematic commas
            cell_value = cell_value.replace(u',', u' ')
            # Append values to the row
            csv_row.append(cell_value)
        # Append row to the output
        csv_output.append(u",".join(csv_row))
    return csv_output


def dict_to_flat(target_dict):
    """
    Receives nested dictionary and returns it as a flat dictionary.
    :param target_dict: {dict}
    :return: Flat dict : {dict}
    """
    target_dict = copy.deepcopy(target_dict)

    def expand(raw_key, raw_value):
        key = raw_key
        value = raw_value
        """
        :param key: {string}
        :param value: {string}
        :return: Recursive function.
        """
        if value is None:
            return [(get_unicode(key), u"")]
        elif isinstance(value, dict):
            # Handle dict type value
            return [(u"{0}_{1}".format(get_unicode(key),
                                       get_unicode(sub_key)),
                     get_unicode(sub_value)) for sub_key, sub_value in dict_to_flat(value).items()]
        elif isinstance(value, list):
            # Handle list type value
            count = 1
            l = []
            items_to_remove = []
            for value_item in value:
                if isinstance(value_item, dict):
                    # Handle nested dict in list
                    l.extend([(u"{0}_{1}_{2}".format(get_unicode(key),
                                                     get_unicode(count),
                                                     get_unicode(sub_key)),
                               sub_value)
                              for sub_key, sub_value in dict_to_flat(value_item).items()])
                    items_to_remove.append(value_item)
                    count += 1
                elif isinstance(value_item, list):
                    l.extend(expand(get_unicode(key) + u'_' + get_unicode(count), value_item))
                    count += 1
                    items_to_remove.append(value_item)

            for value_item in items_to_remove:
                value.remove(value_item)

            for value_item in value:
                l.extend([(get_unicode(key) + u'_' + get_unicode(count), value_item)])
                count += 1

            return l
        else:
            return [(get_unicode(key), get_unicode(value))]

    items = [item for sub_key, sub_value in target_dict.items() for item in
             expand(sub_key, sub_value)]
    return dict(items)


def flat_dict_to_csv(flat_dict, property_header=u"Property", value_header=u"Value"):
    """
    Turns flat dict to CSV format string list. property_header and value_header are for customizing the CSV header
    :param flat_dict: {dict}
    :param property_header: {unicode}
    :param value_header: {unicode}
    :return: CSV format string list : {list}
    """
    csv_format = []
    csv_head = u"{}, {}".format(property_header, value_header)
    csv_format.append(csv_head)
    for key, value in flat_dict.items():
        safe_key = get_unicode(key)
        safe_value = get_unicode(value)
        csv_format.append(u"{0},{1}".format(safe_key, safe_value))
    return csv_format


def add_prefix_to_dict(given_dict, prefix):
    """
    add prefix to the given dict keys
    :param given_dict: {dict}
    :param prefix: {string} prefix to be added to the given dict
    :return: {dict}
    """
    return {u'{0}_{1}'.format(get_unicode(prefix), get_unicode(key)): value for key, value in given_dict.items()}


def add_prefix_to_dict_keys(target_dict, prefix):
    """
    add prefix to the given dict keys
    :param target_dict: {dict}
    :param prefix: {string} prefix to be added to the given dict
    :return: Result Dictionary {dict}
    """
    result_dict = {}
    for key, val in target_dict.iteritems():
        new_key = u"{0}_{1}".format(get_unicode(prefix), get_unicode(key))
        result_dict[new_key] = val

    return result_dict


def get_unicode(value):
    if isinstance(value, unicode):
        return value
    if not isinstance(value, basestring):
        # Validate that the cell is a basestring. If not convert it to string
        try:
            value = str(value)
        except Exception:
            value = u"Unable to get text representation of object"
    if value is None:
        # If the value is empty, leave the cell empty
        value = u""
    if isinstance(value, str):
        try:
            value = value.decode("utf8")
        except UnicodeDecodeError:
            try:
                encoding = chardet.detect(value).get('encoding')
                value = value.decode(encoding)
            except Exception:
                value = u"Unable to decode value (unknown encoding)"

    return value
