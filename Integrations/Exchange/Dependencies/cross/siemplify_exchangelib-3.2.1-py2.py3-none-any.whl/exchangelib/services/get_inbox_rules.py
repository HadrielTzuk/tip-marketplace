# Custom code
from .common import EWSAccountService
from ..util import create_element, set_xml_value, MNS
from ..properties import Rule
from ..errors import MalformedResponseError


class GetInboxRules(EWSAccountService):
    SERVICE_NAME = "GetInboxRules"
    element_container_name = '{%s}InboxRules' % MNS

    def call(self, mailbox_address):
        payload = self.get_payload(mailbox_address)

        response = self._get_elements(payload=payload)

        try:
            for item in response:
                if isinstance(item, Exception):
                    raise item

                yield Rule.from_xml(elem=item, account=self.account)

        except MalformedResponseError:
            return []

    def get_payload(self, mailbox_address):
        get_inbox_rules = create_element('m:%s' % self.SERVICE_NAME)
        mailbox_smtp_address = create_element('m:MailboxSmtpAddress')
        set_xml_value(mailbox_smtp_address, mailbox_address, version=self.account.version)
        get_inbox_rules.append(mailbox_smtp_address)
        return get_inbox_rules
