# Custom code

RULE_OPERATIONS = {
    "create": "create",
    "update": "update",
    "delete": "delete",
}

RULE_CONDITIONS = {
    "from_addresses": "from_addresses",
    "contains_sender_strings": "contains_sender_strings",
}

RULE_ACTIONS = {
    "mark_as_junk": "mark_as_junk",
    "delete": "delete",
    "permanent_delete": "permanent_delete",
}
