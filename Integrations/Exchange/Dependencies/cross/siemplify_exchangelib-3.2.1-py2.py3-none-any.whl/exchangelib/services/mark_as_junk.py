# Custom code
from ..errors import ResponseMessageError
from .common import EWSAccountService
from ..util import create_element


class MarkAsJunk(EWSAccountService):
    SERVICE_NAME = 'MarkAsJunk'

    def call(self, item_id, is_junk, move_item):
        payload = self.get_payload(item_id=item_id, is_junk=is_junk, move_item=move_item)
        elements = list(self._get_elements(payload=payload))

        for element in elements:
            if isinstance(element, ResponseMessageError):
                return element.message

        return "Success"

    def get_payload(self, item_id, is_junk, move_item):
        junk = create_element(
            'm:%s' % self.SERVICE_NAME,
            {
                "IsJunk": "true" if is_junk else "false",
                "MoveItem": "true" if move_item else "false"
            }
        )

        items_list = create_element('m:ItemIds')
        item_element = create_element("t:ItemId", {"Id": item_id})
        items_list.append(item_element)
        junk.append(items_list)

        return junk
