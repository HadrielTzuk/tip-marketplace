# Custom code
from .common import EWSAccountService
from ..util import create_element, set_xml_value
from .constants import RULE_OPERATIONS, RULE_CONDITIONS, RULE_ACTIONS

PRIORITY = 1
IS_ENABLED = "true"
IS_IN_ERROR = "false"


class UpdateInboxRules(EWSAccountService):
    SERVICE_NAME = "UpdateInboxRules"

    def call(self, operation, rule_id=None, rule_name=None, condition=None, action=None, items=None, folder_id=None):
        payload = self.get_payload(operation, rule_id, rule_name, condition, action, items, folder_id)
        response = self._get_elements(payload=payload)

        for element in response:
            if isinstance(element, Exception):
                return element.message

        return True

    def create_element_with_value(self, name, value):
        element = create_element(name)
        set_xml_value(element, value, version=self.account.version)
        return element

    def get_payload(self, operation, rule_id=None, rule_name=None, condition=None, action=None, items=None,
                    folder_id=None):
        update_inbox_rules = create_element('m:%s' % self.SERVICE_NAME)
        update_inbox_rules.append(self.create_element_with_value("m:RemoveOutlookRuleBlob", "true"))
        operations = create_element("m:Operations")

        if operation == RULE_OPERATIONS.get("delete"):
            operation = create_element("t:DeleteRuleOperation")
            operation.append(self.create_element_with_value("t:RuleId", rule_id))
        elif operation == RULE_OPERATIONS.get("create"):
            operation = create_element("t:CreateRuleOperation")
            operation.append(self.get_rule_payload(rule_id, rule_name, condition, action, items, folder_id))
        elif operation == RULE_OPERATIONS.get("update"):
            operation = create_element("t:SetRuleOperation")
            operation.append(self.get_rule_payload(rule_id, rule_name, condition, action, items, folder_id))

        if operation:
            operations.append(operation)

        update_inbox_rules.append(operations)
        return update_inbox_rules

    def get_rule_payload(self, rule_id, rule_name, condition, action, items, folder_id):
        rule = create_element("t:Rule")

        if rule_id:
            rule.append(self.create_element_with_value("t:RuleId", rule_id))

        rule.append(self.create_element_with_value("t:DisplayName", rule_name))
        rule.append(self.create_element_with_value("t:Priority", PRIORITY))
        rule.append(self.create_element_with_value("t:IsEnabled", IS_ENABLED))
        rule.append(self.create_element_with_value("t:IsInError", IS_IN_ERROR))
        rule.append(self.get_conditions_payload(condition, items))
        rule.append(self.get_actions_payload(action, folder_id))

        return rule

    def get_conditions_payload(self, condition, items):
        conditions = create_element("t:Conditions")

        if condition == RULE_CONDITIONS.get("contains_sender_strings"):
            condition = create_element("t:ContainsSenderStrings")

            for item in items:
                condition.append(self.create_element_with_value("t:String", item))

        if condition == RULE_CONDITIONS.get("from_addresses"):
            condition = create_element("t:FromAddresses")

            for item in items:
                address = create_element("t:Address")
                address.append(self.create_element_with_value("t:EmailAddress", item))
                condition.append(address)

        conditions.append(condition)
        return conditions

    def get_actions_payload(self, action, folder_id=None):
        actions = create_element("t:Actions")

        if action == RULE_ACTIONS.get("mark_as_junk"):
            move_to_folder = create_element("t:MoveToFolder")
            move_to_folder.append(create_element("t:FolderId", {"Id": folder_id}))
            actions.append(move_to_folder)

        if action == RULE_ACTIONS.get("delete"):
            actions.append(self.create_element_with_value("t:Delete", "true"))

        if action == RULE_ACTIONS.get("permanent_delete"):
            actions.append(self.create_element_with_value("t:PermanentDelete", "true"))

        actions.append(self.create_element_with_value("t:StopProcessingRules", "true"))

        return actions
