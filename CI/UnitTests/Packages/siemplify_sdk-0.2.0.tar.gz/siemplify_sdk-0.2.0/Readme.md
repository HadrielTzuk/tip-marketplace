This is the Siemplify SDK, which allows to develop and test new integrations for Siemplify.

# Building
1. First name sure that you have the latest version of setuptools and wheel:
python2 -m pip install --user --upgrade setuptools wheel
2. Next within the same folder as setup.py you need to run this command to build:
python2 setup.py sdist bdist_wheel

# Installation
At the moment package iesn't available on PyPi, so you'll have to install it from local sources like this?
1. Launch your virtualenv:
virtualenv venv
source ./venv/bin/activate
2. Install the package via pip:
pip install siemplify_sdk --no-index --find-links file://<Path to SiemplifySDK folder>/dist

