﻿import sys
import json
from Siemplify import Siemplify
from SiemplifyUtils import extract_script_param

class SiemplifyJob(Siemplify):

    def __init__(self):
        super(SiemplifyJob, self).__init__()
        raw_context_data = sys.stdin.read()
        context_data = json.loads(raw_context_data.decode("utf-8-sig"))
        self.parameters = self._fix_parameters(context_data['parameters'])

    def get_configuration(self, provider, environment=""):
        """
        Get integration configuration
        :param provider: {string} integration name (e.g. "VirusTotal")
        :param environment: {string} configuration for specific environment or 'all'
        :return: {dict} configuration details
        """
        return super(SiemplifyJob, self).get_configuration(provider, "")

    def get_system_info(self,start_time_unixtime_ms):
        return super(SiemplifyJob, self).get_system_info(start_time_unixtime_ms)

    @property
    def log_location(self):
        return "SDK_Jobs"

    def extract_job_param(self, param_name, default_value=None, input_type=str, is_mandatory=False, print_value=False):
        return extract_script_param(siemplify=self,
                                    input_dictionary=self.parameters,
                                    param_name=param_name,
                                    default_value=default_value,
                                    input_type=input_type,
                                    is_mandatory=is_mandatory,
                                    print_value=print_value)
