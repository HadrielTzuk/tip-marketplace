import os
import SiemplifyUtils
import json
import traceback
from SiemplifySdkConfig import SiemplifySdkConfig

# CONSTS
CONNECTOR_OVERFLOW_CONFIG_FILE = "ConnectorsOverflow.config"


class OverflowManager(object):
    OVERFLOW_DATA_FILENAME = "overflow.data"
    DIGESTION_TIMES_KEY = 'digestion_times'
    NOTIFICATION_TIME_KEY = "last_notification_time"

    def __init__(self, logger, is_test_run, manager_cache_folder_path, overflow_manager_settings=None,
                 overflow_manager_config_file_path=None):
        self.is_test_run = is_test_run
        self.LOGGER = logger
        self._manager_cache_folder_path = manager_cache_folder_path
        self.reported_overflows = []
        self.DEFAULT_CONFIG_FILE_PATH = \
            os.path.join(SiemplifySdkConfig().config_files_root_path, CONNECTOR_OVERFLOW_CONFIG_FILE)
        overflow_manager_config_file_path = \
            overflow_manager_config_file_path if overflow_manager_config_file_path else self.DEFAULT_CONFIG_FILE_PATH

        if not overflow_manager_settings and not overflow_manager_config_file_path:
            raise Exception(
                "'overflow_manager_settings' or a valid 'overflow_manager_config_file_path' must be provided")

        if overflow_manager_settings and overflow_manager_config_file_path:
            raise Exception(
                "Expected only one initlization param 'overflow_manager_settings' or a valid 'overflow_manager_config_file_path', both were provided")

        if overflow_manager_config_file_path:
            if not os.path.exists(overflow_manager_config_file_path):
                raise Exception(
                    "overflow_manager_config_file_path {0} doesn't exist".format(overflow_manager_config_file_path))

            self._settings = self._load_settings_from_file(overflow_manager_config_file_path)
        else:
            self._settings = overflow_manager_settings

        if not os.path.exists(self._manager_cache_folder_path):
            raise Exception("Overflowmanager error: given cache folder doesn't exist")

    @property
    def overflow_data_file_path(self):
        """
        :return: {string} cache_file_path
        """
        return os.path.join(self._manager_cache_folder_path, self.OVERFLOW_DATA_FILENAME)

    @staticmethod
    def _load_settings_from_file(file_path):
        """
        load settings
        :param file_path: {string} settings file path
        :return: OverflowManagerSettings
        """
        f = open(file_path, 'r')
        json_content = f.read()
        manager_json = json.loads(json_content, encoding="utf8")
        manager_settings = OverflowManagerSettings(**manager_json)
        f.close()

        return manager_settings

    def check_is_alert_overflowed(self, overflow_alert_details):
        """
        Check if alert is overflowed. If yes - report it.
        :param overflow_alert_details:
        :return: {boolean} True if alert is overflowed
        """
        oad = overflow_alert_details

        if not self._settings.is_overflow_enabled:
            return False

        if self.is_test_run:
            self.LOGGER.info("Overflow not checked because this is a test run")
            return False

        if not oad:
            raise Exception("Error check overflow, given overflow_alert_details is empty")

        result = True

        try:
            overflow_cache = self._load_alerts_overflow_cache_from_file()
            self._clear_old_alerts_times(overflow_cache)

            alert_identifier = self._build_alert_identifier(oad)

            if alert_identifier not in overflow_cache:
                overflow_cache[alert_identifier] = {self.DIGESTION_TIMES_KEY: [],  # digestions unix times list
                                                    self.NOTIFICATION_TIME_KEY: 0}  # last notification unix time

            current_alert_digestion_times = overflow_cache[alert_identifier][self.DIGESTION_TIMES_KEY]

            # keep it for legacy purposes.
            # until we can unsure no customer code is calling it anymore
            # current_alert_last_notification_time = overflow_cache[alert_identifier][self.NOTIFICATION_TIME_KEY]

            if len(current_alert_digestion_times) < self._settings.max_alerts_in_time_period:
                result = False

            current_alert_digestion_times.append(SiemplifyUtils.unix_now())

            if result:
                # We no longer consider notification time, we just always pass the overflow alert.
                # time_since_last_notificaiton = SiemplifyUtils.unix_now()-current_alert_last_notification_time
                # if (time_since_last_notificaiton>(self._settings.notification_interval_minutes*60*1000)):

                overflow_cache[alert_identifier][self.NOTIFICATION_TIME_KEY] = SiemplifyUtils.unix_now()
                self._report_alert_as_overflow(oad)

            self._save_alerts_overflow_cache_to_file(overflow_cache)

        except Exception as e:
            msg = "Error checking overflow for {0}, Details: {1} {2}".format(
                oad.original_file_path, str(e), traceback.format_exc())
            raise Exception(msg)

        return result

    def _load_alerts_overflow_cache_from_file(self):
        """
        Open overflow file cache and validate last notification_time
        :return: overflow cache data
        """
        overflow_cache = {}
        if os.path.exists(self.overflow_data_file_path):
            try:
                with open(self.overflow_data_file_path, 'r') as f:
                    json_content = f.read()
                    f.close()

                overflow_cache = json.loads(json_content,  encoding="utf8")
            except Exception as e:
                overflow_cache = {}
                self.LOGGER.error("Failed to open or parse Overflow cache file {}".format(self.overflow_data_file_path))
                self.LOGGER.exception(e)

        # validate last notification_time values:
        for alert_identifier in overflow_cache:
            # Get Last notification time from file cache
            if self.NOTIFICATION_TIME_KEY in overflow_cache[alert_identifier]:
                overflow_cache[alert_identifier][self.NOTIFICATION_TIME_KEY] = long(
                    overflow_cache[alert_identifier][self.NOTIFICATION_TIME_KEY])
            else:
                overflow_cache[alert_identifier][
                    self.NOTIFICATION_TIME_KEY] = 0  # Init when missing, for legacy support

        return overflow_cache

    def _save_alerts_overflow_cache_to_file(self, alert_times):
        """
        Save cache to file
        :param alert_times: {dict} overflow cache
        """
        json_content = json.dumps(alert_times, sort_keys=True, indent=4, separators=(',', ': '), encoding="utf8")

        with open(self.overflow_data_file_path, 'w') as time_file:
            time_file.write(json_content)
            time_file.close()

    def _clear_old_alerts_times(self, overflow_cache):
        """
        remove old alerts
        :param overflow_cache: {dict} overflow cache
        """
        for alert_identifier in overflow_cache:
            times_to_remove = []
            current_alert_digestion_times = overflow_cache[alert_identifier][self.DIGESTION_TIMES_KEY]
            for timestamp in current_alert_digestion_times:
                time_passed_minutes = (SiemplifyUtils.unix_now() - timestamp) / float(1000) / float(60)
                if time_passed_minutes > self._settings.time_period_in_min:
                    times_to_remove.append(timestamp)

            for overdue_time in times_to_remove:
                current_alert_digestion_times.remove(overdue_time)

    def _build_alert_identifier(self, overflow_alert_details):
        """
        create alert overflow key
        :param overflow_alert_details: (overflow settings - environment, product, etc)
        :return: {string} alert key
        """
        oad = overflow_alert_details
        result = ""

        if self._settings.is_environment_considered:
            result += "|" + oad.environment

        if self._settings.is_product_considered:
            product = ""
            if oad.product:
                product = oad.product
            result += "|" + product

        if self._settings.is_rule_generator_considered:
            result += "|" + oad.alert_name

        return result

    def _report_alert_as_overflow(self, overflow_alert_details):
        """
        report alert as overflow
        :param overflow_alert_details: (overflow settings - environment, product, etc)
        """

        # We need to convert to pascal case for C# json serialier:
        # save_content = overflow_alert_details.return_pascal_case_dictionary()
        # json_content = json.dumps(save_content, sort_keys=True, indent=4, separators=(',', ': '))
        # self.reported_overflows.append(save_content)

        self.reported_overflows.append(overflow_alert_details)


class OverflowManagerSettings(object):
    def __init__(self, is_overflow_enabled=True, is_environment_considered=True, is_product_considered=True,
                 is_rule_generator_considered=True, max_alerts_in_time_period=50, time_period_in_min=10):
        self.is_overflow_enabled = is_overflow_enabled
        self.is_environment_considered = is_environment_considered
        self.is_product_considered = is_product_considered
        self.is_rule_generator_considered = is_rule_generator_considered
        self.max_alerts_in_time_period = max_alerts_in_time_period
        self.time_period_in_min = time_period_in_min


class OverflowAlertDetails(object):
    def __init__(self, environment, source_system_name, connector_identifier, original_file_path, original_file_content,
                 ingestion_time, alert_identifier, alert_name=None, product=None, source_ip=None, source_host=None,
                 destination_ip=None, destination_host=None):
        self.environment = self.empty_if_none(environment)
        self.source_system_name = self.empty_if_none(source_system_name)
        self.connector_identifier = self.empty_if_none(connector_identifier)
        self.original_file_path = self.empty_if_none(original_file_path)
        self.original_file_content = self.empty_if_none(original_file_content)
        self.ingestion_time = ingestion_time
        self.alert_identifier = self.empty_if_none(alert_identifier)
        self.alert_name = self.empty_if_none(alert_name)
        self.product = self.empty_if_none(product)
        self.source_ip = self.empty_if_none(source_ip)
        self.source_host = self.empty_if_none(source_host)
        self.destination_ip = self.empty_if_none(destination_ip)
        self.destination_host = self.empty_if_none(destination_host)

        if not ingestion_time:
            raise Exception("ingestion_time cannot be None")

    @staticmethod
    def empty_if_none(s):
        if s is None:
            return ""
        return str(s)
