import logging.handlers
import logging.config
import json
import os
from abc import ABCMeta, abstractmethod
import arrow
from SiemplifyDataModel import ConnectorLogRecord, LogRecordTypeEnum, ActionLogRecord
from SiemplifySdkConfig import SiemplifySdkConfig

# CONSTS
LOG_CONFIG_FILE = 'ScriptingLogging.config'


class SiemplifyLogger(object):
    DEFAULT_LOGGER_NAME = "siemplify_default_logger"
    DEFAULT_FILE_HANDLER_NAME = "siempify_file_handler"
    DEFAULT_ELASTICSEARCH_HANDLER_NAME = "siempify_elasticsearch_handler"
    DEFAULT_LOG_FILE_NAME = "logdata.log"
    DEFAULT_LOG_LOCATION = "SDK"

    def __init__(self, run_folder, log_location=DEFAULT_LOG_LOCATION, module=None, logs_collector=None):
        self.CONFIG_FILE_PATH = os.path.join(SiemplifySdkConfig().config_files_root_path, LOG_CONFIG_FILE)
        self._error_logged = False
        self._log = None
        self._logs_collector = logs_collector
        try:
            config = self.loadConfigFromFile(run_folder, log_location)
            logging.config.dictConfig(config)
            self._log = logging.getLogger(self.DEFAULT_LOGGER_NAME)
            self.module = module
        except:
            print("LOGGER: Error initliazing.")

    def loadConfigFromFile(self, run_folder, log_location):
        """
        load config file
        :param run_folder: {string} running folder path
        :param log_location: {string} elastic search log location
        :return:
        """
        try:
            configfile = open(self.CONFIG_FILE_PATH, "r")
            config_json_string = configfile.read()
            configfile.close()
            logging_config_from_file = json.loads(config_json_string)

            handlers = logging_config_from_file["handlers"]
            if self.DEFAULT_FILE_HANDLER_NAME in handlers:
                handlers[self.DEFAULT_FILE_HANDLER_NAME]["filename"] = os.path.join(run_folder,
                                                                                    self.DEFAULT_LOG_FILE_NAME)

            if self.DEFAULT_ELASTICSEARCH_HANDLER_NAME in handlers:
                handlers[self.DEFAULT_ELASTICSEARCH_HANDLER_NAME]["es_additional_fields"]["location"] = log_location

            return logging_config_from_file
        except:
            print "LOGGER: loadConfigFromFile FAILED"

    def exception(self, message, *args, **kwargs):
        """
        configure log - type exception
        :param message: {string} exception message
        """
        self._error_logged = True

        try:
            self.safe_print(message)
            if self._log:
                if isinstance(message, Exception):
                    escaped_msg = unicode(message.message).replace("%", "%%")
                else:
                    escaped_msg = message.replace("%", "%%")

                if self.module:
                    kwargs.update({'module': self.module})

                if kwargs:
                    self._log.error(escaped_msg, kwargs, exc_info=True)
                else:
                    self._log.error(escaped_msg, exc_info=True)

            if self._logs_collector:
                self._logs_collector.collect(message, LogRecordTypeEnum.ERROR)
        except:
            print "LOGGER.exception FAILED."

    def error(self, message,*args, **kwargs):
        """
        configure log - type error
        :param message: {string} exception message
        """
        self._error_logged = True

        try:
            self.safe_print(message)
            if self._log:
                if self.module:
                    kwargs.update({'module': self.module})
                if kwargs:
                    self._log.error(message.replace("%", "%%"), kwargs)
                else:
                    self._log.error(message)
            if self._logs_collector:
                self._logs_collector.collect(message, LogRecordTypeEnum.ERROR)
        except:
            print "LOGGER.error FAILED"

    def warn(self, message, *args, **kwargs):
        """
        configure log - type warn
        :param message: {string} exception message
        """
        try:
            self.safe_print(message)
            if self._log:
                if self.module:
                    kwargs.update({'module': self.module})
                if kwargs:
                    self._log.warn(message.replace("%", "%%"), kwargs)
                else:
                    self._log.warn(message)
            if self._logs_collector:
                self._logs_collector.collect(message, LogRecordTypeEnum.ERROR)
        except:
            print "LOGGER.warn FAILED"

    def info(self, message, *args, **kwargs):
        """
        configure log - type info
        :param message: {string} exception message
        """
        try:
            self.safe_print(message)
            if self._log:
                if self.module:
                    kwargs.update({'module': self.module})
                if kwargs:
                    self._log.info(message.replace("%", "%%"), kwargs)
                else:
                    self._log.info(message)
            if self._logs_collector:
                self._logs_collector.collect(message, LogRecordTypeEnum.INFO)
        except:
            print "LOGGER.info FAILED {0}"

    @staticmethod
    def safe_print(message):
        if isinstance(message, unicode):
            print message.encode('utf-8')
        elif isinstance(message, str):
            print message
        else:
            try:
                print unicode(message).encode('utf-8')
            except:
                print "Couldn't print exception, check log"

    @property
    def error_logged(self):
        return self._error_logged


class SiempplifyConnectorsLogger(object):
    _log_items = []

    def error(self, message):
        msg = "ERROR | " + str(message)
        print msg
        self._log_items.append(msg)

    def warn(self, message):
        msg = "WARN | " + str(message)
        print msg
        self._log_items.append(msg)

    def info(self, message):
        msg = "INFO | " + str(message)
        print msg
        self._log_items.append(msg)


class FileLogsCollector(object):
    __metaclass__ = ABCMeta
    LOG_COLLECTOR_FILENAME = "logs_collector.json"

    def __init__(self, file_dir):
        self.log_collector_file_path = os.path.join(file_dir, self.LOG_COLLECTOR_FILENAME)

    @abstractmethod
    def create_log_record(self,message, log_type):
        raise NotImplementedError

    def collect(self, message, log_type):
        log_record = self.create_log_record(message, log_type)
        log_items = []
        try:
            if os.path.exists(self.log_collector_file_path):
                log_items = json.load(open(self.log_collector_file_path, "r"))

            with open(self.log_collector_file_path, 'w') as logs_collector:
                log_items.append(log_record)
                logs_collector.write(json.dumps(log_items, default=lambda o: o.__dict__))

        except Exception:
            print "LOGGER: add log record to collector FAILED"


class ConnectorsFileLogsCollector(FileLogsCollector):
    """Collect connectors logs to a file"""
    def __init__(self, file_dir, connector_context):
        super(ConnectorsFileLogsCollector, self).__init__(file_dir)
        self.connector_context = connector_context

    def create_log_record(self, message, log_type):
        log_record = ConnectorLogRecord(
            record_type=log_type,
            message=message,
            connector_identifier=self.connector_context.connector_info.identifier,
            result_data_type=self.connector_context.connector_info.result_data_type,
            source_system_name=self.connector_context.connector_info.integration,
            connector_definition_name=self.connector_context.connector_info.connector_definition_name,
            integration=self.connector_context.connector_info.integration,
            timestamp=arrow.utcnow().timestamp
        )
        return log_record


class ActionsFileLogsCollector(FileLogsCollector):
    """Collect actions logs to a file"""
    def __init__(self, file_dir, context_data):
        super(ActionsFileLogsCollector, self).__init__(file_dir)
        self.context_data = context_data

    def create_log_record(self, message, log_type):
        log_record = ActionLogRecord(
            record_type=log_type,
            message=message,
            case_id=self.context_data['case_id'],
            alert_id=self.context_data['alert_id'],
            workflow_id=self.context_data['workflow_id'],
            environment=self.context_data["environment"],
            action_definition_name=self.context_data["action_definition_name"],
            integration=self.context_data["integration_identifier"],
            timestamp=arrow.utcnow().timestamp
        )

        return log_record