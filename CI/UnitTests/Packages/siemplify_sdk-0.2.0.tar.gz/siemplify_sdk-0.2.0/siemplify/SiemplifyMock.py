import json
import os
import sys
from OverflowManager import OverflowManager
from SiemplifyConnectors import SiemplifyConnectorExecution
from SiemplifyDataModel import Attachment
from SiemplifyJob import SiemplifyJob
from SiemplifyUtils import my_stdout
from SiemplifyBase import SiemplifyBase
from SiemplifyConnectorsDataModel import ConnectorContext
import ScriptResult
from SiemplifyAction import SiemplifyAction
import requests


HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}


class EntityMock(object):
    def __init__(self, entity_type, identifier):
        self.identifier = identifier
        self.entity_type = entity_type



# Itaih:  This is legacy mock runners, I don't see use for it, it's not working very well (
# class SiemplifyMock(SiemplifyBase):
#
#
#     def __init__(self):
#         super(SiemplifyMock, self).__init__()
#
#         self.case_id = 1
#         self.alert_id = "mock_alert_id"
#
#         self.workflow_id = '0'
#         action_data_file = __file__
#         self._action_data = ActionData.load()
#         self.parameters = self._action_data.parameters
#         self.target_entity_ids = self._action_data.entities
#         #self._proxy_settings = self._set_proxy_state()
#         self._attachments = []
#         self._api_key = "sTeTXLRvCvYGjePew/OJkg=="
#         self.api_key = "sTeTXLRvCvYGjePew/OJkg=="
#         self.API_ROOT = self.sdk_config.api_root_uri
#         self.API_ROOT = "https://localhost:8443/api/external/v1/sdk"
#
#         # Create regular Session
#         self.session = requests.Session()
#         self.session.verify = False
#         HEADERS.update({"AppKey": self.api_key})
#         self.session.headers.update(HEADERS)
#         #self._set_proxy_state()
#
#
#     @property
#     def log_location(self):
#         return "SDK_Mocks"
#
#     def _get_case_by_id(self, case_id):
#         with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mock_case_data.json"),
#                   "r") as mock_data_file:
#             mock_case_data = json.loads(mock_data_file.read())
#             mock_data_file.close()
#             return mock_case_data
#
#     def _load_current_alert(self):
#         for alert in self.case.alerts:
#             if alert.identifier == self.alert_id:
#                 self._current_alert = alert
#                 return
#         self._current_alert = None
#
#     def _load_target_entities(self):
#         target_entities = {}
#         for entity in [entity for alert in self.case.alerts for entity in alert.entities]:
#             if entity.identifier in self.target_entity_ids and entity.identifier not in target_entities:
#                 target_entities[entity.identifier] = entity
#         self._target_entities = target_entities.values()
#
#     def update_entities(self, updated_entities):
#         for entity in updated_entities:
#             entity._update_internal_properties()
#         pass
#
#     def add_attachment(self, file_path, case_id=None, alert_identifier=None, description=None, is_favorite=False):
#         attachment = Attachment.fromfile(file_path)
#         attachment.case_identifier = self.case_id
#         self._attachments.append(attachment)
#
#     def get_attachments(self, case_id=None):
#         return self._attachments
#
#     def get_attachment(self, attachment_id):
#         return self._attachments[0]
#
#     def get_configuration(self, provider, environment=None):
#         if provider in self._action_data.configuration:
#             return self._action_data.configuration[provider]
#         return {}
#
#     def get_system_info(self,start_time_unixtime_ms):
#         return super(SiemplifyJob, self).get_system_info(start_time_unixtime_ms)
#
#     def get_system_info(self, start_time_unixtime_ms):
#
#         address = "{0}/{1}/{2}{3}".format(self.API_ROOT, "SystemInfo", start_time_unixtime_ms, "?format=snake")
#         response = self.session.get(address)
#         self.validate_siemplify_error(response)
#         system_info = response.json()
#
#         return system_info
#
#     def validate_siemplify_error(self, response):
#         pass

API_TOKEN = "sTeTXLRvCvYGjePew/OJkg=="
STDIN_FILE_PATH = r"C:\@\Dynamo-1.97\Common\Siemplify.Common.PythonSDK\Scripting\PythonSDK\mock_std_in.txt"
STDIN_FILE_NAME = "mock_std_in.txt"

def get_mock_stdin():
    stdin = "EMPTY ERROR PLEASE FEED ME"

    std_mock_path = STDIN_FILE_NAME # Used on Mock run from SDK Folder
    if not os.path.isfile(std_mock_path):
        std_mock_path = STDIN_FILE_PATH # used on Action run, from marketplace
    with open(std_mock_path, "r") as f:
        stdin = f.read()
        f.close

    return stdin

class SiemplifyActionMock(SiemplifyAction):
    def __init__(self):
        sys.argv.append(API_TOKEN)  # api token
        super(SiemplifyActionMock, self).__init__(mock_stdin=get_mock_stdin())

    @property
    def log_location(self):
        return "SDK_Mocks"

    def validate_siemplify_error(self, response):
        pass


class ActionData:

    def __init__(self, name, description, result_name, category, parameters,
                 configuration, entities):
        self.name = name
        self.description = description
        self.result_name = result_name
        self.category = category
        self.parameters = parameters
        self.configuration = configuration
        self.entities = entities

    @classmethod
    def load(cls, action_data_file=None):
        if action_data_file is None:
            action_data_file = os.path.splitext(os.path.basename(sys.argv[0]))[0] + ".json"

        folder_base = os.path.dirname(sys.argv[0])
        file_path = os.path.join(folder_base, action_data_file)
        if not os.path.exists(file_path):
            file_path = os.path.join(folder_base, "mock_action_data.json")

        with open(file_path, "r") as action_data:
            data = json.load(action_data)
            data["category"] = data["configuration"].keys()[0]
            return ActionData(**data)


class SiemplifyConnectorMock(SiemplifyConnectorExecution):
    """
    Siemplify Connector Mock
    """

    def __init__(self, parameters=None, whitelist=None, connector_name=''):
        """
        Construct Connector Mock
        :param parameters: {dixt} Dict of param in the following format:
            {
                "Your Param Name": "The Param Value" # Always a string
            }
        :param whitelist: {list} the whitelist of the connector (list of strings).
        :param connector_name {string} for specifying script_name (for assets folder)
        """
        oldstdin = sys.stdin
        raw_data = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mock_connector_data.json")).read()
        sys.stdin = StringIO(raw_data)
        super(SiemplifyConnectorMock, self).__init__()
        sys.stdin = oldstdin

        self.context.connector_info.display_name = connector_name
        self.overflow_manager = OverflowManager(manager_cache_folder_path=self.run_folder, logger=self.LOGGER,
                                                is_test_run=self.is_test_run)

        self.context.connector_info.white_list = whitelist or []
        if parameters:
            for param_name, param_value in parameters.items():
                self.context.connector_info.params.append({
                    "param_name": param_name,
                    "param_value": param_value
                })

    def return_package(self, cases, output_variables, log_items):
        connector_output = {}
        connector_output['cases'] = cases
        connector_output['log_items'] = log_items
        connector_output['variables'] = output_variables

        output_object = {}
        output_object["ResultObjectJson"] = json.dumps(connector_output, default=lambda o: o.__dict__)
        output_object["DebugOutput"] = my_stdout.getvalue()

        return output_object

    def return_test_result(self, is_success, result_params_dictionary):
        connector_test_output = {}
        connector_test_output['is_success'] = is_success
        connector_test_output['result_params'] = result_params_dictionary

        output_object = {}
        output_object["ResultObjectJson"] = json.dumps(connector_test_output, default=lambda o: o.__dict__)
        output_object["DebugOutput"] = my_stdout.getvalue()

        return output_object


class SiemplifyJobMock(SiemplifyJob):
    def __init__(self, parameters=None, api_key=''):
        """
        Construct Job Mock
        :param parameters: {dict} The parameters to the action, in the following format:
            {
                "param name": "param value"
            }
            The value is always a string.
        :param api_key {string} api key for siemplify server
        """
        sys.argv.append(api_key)
        oldstdin = sys.stdin
        raw_data = '{"parameters:{}"}'
        sys.stdin = StringIO(raw_data)
        super(SiemplifyJob, self).__init__()
        sys.stdin = oldstdin

        self.parameters = parameters or {}
