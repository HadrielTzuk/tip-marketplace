import SiemplifyLogger
import SiemplifyUtils
from SiemplifySdkConfig import SiemplifySdkConfig
import datetime
import os


class SiemplifyBase(object):
    TIMESTAMP = "timestamp.stmp"

    def __init__(self):
        self.sdk_config = SiemplifySdkConfig()
        self.RUN_FOLDER = self.sdk_config.run_folder_path
        self.script_name = ""
        self._logger = None
        self._logs_collector = None

    @property
    def run_folder(self):
        """
        build run_folder base on script name
        :return: {string} full path (e.g. C:\Siemplify_Server\Scripting\SiemplifyAction\<script name>)
        """
        path = os.path.join(self.RUN_FOLDER, self.__class__.__name__)

        if not self.script_name:
            raise Exception(
                "Cannot build run_folder when script_name has not been defined first. Try addind: siemplify.script_name='name'")

        path = os.path.join(path, self.script_name)

        if not os.path.exists(path):
            os.makedirs(path)

        return path

    @property
    def log_location(self):
        return "smp_python"

    @property
    def LOGGER(self):
        if not self._logger:
            self._logger = SiemplifyLogger.SiemplifyLogger(self.run_folder, log_location=self.log_location,
                                                           logs_collector=self._logs_collector)

        return self._logger

    def set_logs_collector(self, logs_collector):
        self._logs_collector = logs_collector

    def fetch_timestamp(self, datetime_format=False, timezone=False):
        """
        get timestamp
        :param datetime_format: {boolean} if datetime - return timestamp as datetime
        :param timezone: NOT SUPPORTED anymore!
        :return: {unix time/ datetime}
        """
        save_file_path = os.path.join(self.run_folder, self.TIMESTAMP)

        last_run_time = 0
        if os.path.isfile(save_file_path):
            with open(save_file_path, 'r') as f:
                last_run_time = f.read()
                f.close()

        try:
            last_run_time = long(last_run_time)
        except:
            last_run_time = SiemplifyUtils.convert_string_to_unix_time(last_run_time)

        if datetime_format:
            last_run_time = SiemplifyUtils.convert_unixtime_to_datetime(last_run_time)

            # SiemplifyUtils.convert_timezone is unsupported for DST, so was removed
            if timezone:
                last_run_time = SiemplifyUtils.convert_timezone(last_run_time, timezone)
        else:
            last_run_time = long(last_run_time)

        return last_run_time

    def save_timestamp(self, datetime_format=False, timezone=False, new_timestamp=SiemplifyUtils.unix_now()):
        """
        save timestamp
        :param datetime_format: {boolean} if datetime - return timestamp as datetime
        :param timezone:  NOT SUPPORTED anymore!
        :param new_timestamp: {long} unix time
        """
        save_file_path = os.path.join(self.run_folder, self.TIMESTAMP)

        if isinstance(new_timestamp, datetime.datetime):
            new_timestamp = SiemplifyUtils.convert_datetime_to_unix_time(new_timestamp)

        if datetime_format:
            new_timestamp = SiemplifyUtils.convert_unixtime_to_datetime(new_timestamp)

            # SiemplifyUtils.convert_timezone is unsupported for DST, so was removed
            if timezone:
                new_timestamp = SiemplifyUtils.convert_timezone(new_timestamp, timezone)

        with open(save_file_path, 'w') as time_file:
            time_file.write(str(new_timestamp))
            time_file.close()

    def fetch_and_save_timestamp(self, datetime_format=False, timezone=False, new_timestamp=SiemplifyUtils.unix_now()):
        """
        fetach and save timestamp
        :param datetime_format: {boolean} if datetime - return timestamp as datetime
        :param timezone: NOT SUPPORTED anymore!
        :param new_timestamp: {long} unix time
        :return: {unix time/ datetime}
        """
        last_run_time = self.fetch_timestamp(datetime_format=datetime_format, timezone=timezone)
        self.save_timestamp(datetime_format=datetime_format, timezone=timezone, new_timestamp=new_timestamp)
        return last_run_time
