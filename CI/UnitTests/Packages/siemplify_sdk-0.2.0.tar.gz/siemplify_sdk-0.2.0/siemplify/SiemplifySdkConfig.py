import json
import os


class SiemplifySdkConfig(object):
    def __init__(self):
        current_module_path = os.path.dirname(os.path.abspath(__file__))
        sdk_config_path = os.path.join(current_module_path, 'sdk_config.json')

        # Configure default values
        self.api_root_uri = 'https://localhost:8443/api'
        self.config_files_root_path = r'C:\Siemplify_Server\Configs'
        self.run_folder_path = r'C:\Siemplify_Server\Scripting'
        self.is_remote_publisher_sdk = False

        if os.path.isfile(sdk_config_path):
            try:
                with open(sdk_config_path, 'r') as configFile:
                    config = json.loads(configFile.read())
                    self.api_root_uri = config.get('api_root_uri')
                    self.config_files_root_path = config.get('config_files_root_path')
                    self.run_folder_path = config.get('run_folder_path')
                    self.is_remote_publisher_sdk = config.get('is_remote_publisher_sdk', False)
            except Exception as e:
                # 'Failed to load the configuration file'
                print("Failed to load the configuration file: " + str(e))

    @staticmethod
    def is_windows():
        return os.name == "nt"

    @staticmethod
    def is_linux():
        return os.name == "posix"
