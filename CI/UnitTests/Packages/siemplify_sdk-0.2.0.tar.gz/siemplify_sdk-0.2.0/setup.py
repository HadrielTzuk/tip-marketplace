import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="siemplify_sdk",
    version="0.2.0",
    author="Siemplify's team",
    author_email="garry@siemplify.co",
    description="This is a Siemplify SDK, which allows one to develop integrations for Siemplify platform.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/siemplify/siemplify_sdk",
    packages=setuptools.find_packages(exclude=['contrib', 'docs', 'tests']),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 2.7",
        "License :: Proprietary",
        "Operating System :: MS Windows Server >= 2012 R2",
    ],
    python_requires='>=2.7',
    install_requires=[
        'pytz>=2019.3',
        'arrow>=0.15.2',
    ],
)